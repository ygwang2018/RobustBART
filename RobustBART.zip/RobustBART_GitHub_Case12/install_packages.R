required_packages <- c(
  "EnvStats",
  "bartMachine",
  "MLmetrics",
  "quantreg",
  "boot",
  "randomForest",
  "e1071",
  "modeldata"
)

installed <- rownames(installed.packages())
missing_packages <- setdiff(required_packages, installed)

if (length(missing_packages) > 0L) {
  install.packages(missing_packages, repos = "https://cloud.r-project.org")
} else {
  message("All required R packages are already installed.")
}

message(
  "Note: bartMachine requires a working Java/JDK installation. ",
  "Consult the bartMachine installation documentation if package loading fails."
)
