# Validation notes

## Coverage audit

The supplied archive contains all 16 combinations of:

- Case 1 and Case 2;
- normal, Student t with 3 degrees of freedom, centered chi-square with 6 degrees of freedom, and centered exponential contamination; and
- clean-data proportions 0.55 and 0.95.

Every scenario includes default BART, BART(O), BART(H), BART(B), random forest, and support vector regression.

## Change made for consistency

The supplied `Case1/Case1+t/t095.R` simulation and `realdata/realdata_biomass.R` script used `for (j in 1:100)`. The GitHub copies change both loops to `for (j in 1:200)` to agree with the manuscript statement that Sections 3 and 4 use 200 replications. The obsolete 100-repetition copies are excluded from the public repository to prevent readers from running the wrong versions.

## Item requiring author verification

In every supplied simulation script, the predictor matrix `X` and the true mean `mu_0` are generated once before the Monte Carlo loop. Within each replication, selected entries of `X` are replaced by 5, but `X` is not reset before the next replication. Therefore, the leverage modifications accumulate over the replications while `mu_0` remains based on the original predictor matrix.

The biomass script behaves similarly: `X` is initialized once before the loop and `X <- random_attack2(X, p)` repeatedly changes selected values in its first column to 100. Thus, the attacked rows accumulate across repetitions instead of each repetition applying a fresh 10% random attack to the original predictors.

This package does not change that behavior. Before public release, the authors should determine whether the intended design is:

1. a fixed clean design that is reset before adding leverage points in each replication; or
2. the cumulative modification currently implemented.

If the intended design is option 1, reset `X` from a stored clean matrix inside the loop and rerun all numerical results before updating the manuscript.

## Other implementation observations

- `RF_time` and `svm_time` are overwritten rather than appended inside each loop, so the saved objects retain only the final replication's RF and SVR times.
- The `.Rhistory` files from the submitted archive have been excluded because they are session artifacts rather than reproducibility code.
- The eight copies of `Func1.R` are byte-for-byte identical.
- The case-study `Func1.R` is not interchangeable with the simulation version: among other differences, its returned objects omit the stored `sigma` vectors used by the simulations.
- The biomass script is included, but manuscript table/figure-generation code was not supplied.
- R was unavailable in the packaging environment, so the scripts were statically inspected but not executed here.

## Before describing the repository as complete

- Confirm the intended treatment of `X` across replications.
- Decide whether full RF and SVR timing vectors are required and, if so, append rather than overwrite them.
- Run all scripts in a clean R environment and inspect `results/sessionInfo.txt`.
- Add manuscript table/figure-generation code if the data-availability statement promises complete code.
- Add a software license.
