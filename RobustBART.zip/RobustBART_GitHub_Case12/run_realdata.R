command_args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", command_args, value = TRUE)

if (length(file_arg) > 0L) {
  script_path <- normalizePath(sub("^--file=", "", file_arg[[1L]]))
  repo_root <- dirname(script_path)
} else {
  repo_root <- normalizePath(getwd(), mustWork = TRUE)
}

analysis_dir <- file.path(repo_root, "realdata")
analysis_script <- "realdata_biomass.R"
generated_file <- file.path(analysis_dir, "bio.RData")
results_dir <- file.path(repo_root, "results")
result_file <- file.path(results_dir, "biomass_random_attack.RData")

dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)

rscript_bin <- file.path(
  R.home("bin"),
  if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript"
)

previous_dir <- getwd()
setwd(analysis_dir)
status <- system2(rscript_bin, analysis_script)
setwd(previous_dir)

if (!identical(status, 0L)) {
  stop(sprintf("Biomass analysis failed with status %s.", status))
}

if (!file.exists(generated_file)) {
  stop(sprintf("Expected output was not created: %s", generated_file))
}

copied <- file.copy(generated_file, result_file, overwrite = TRUE)
if (!copied) {
  stop(sprintf("Could not copy output to: %s", result_file))
}

capture.output(
  sessionInfo(),
  file = file.path(results_dir, "sessionInfo_biomass.txt")
)

message("Biomass analysis completed. Output: ", result_file)
