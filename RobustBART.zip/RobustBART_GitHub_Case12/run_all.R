command_args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", command_args, value = TRUE)

if (length(file_arg) > 0L) {
  script_path <- normalizePath(sub("^--file=", "", file_arg[[1L]]))
  repo_root <- dirname(script_path)
} else {
  repo_root <- normalizePath(getwd(), mustWork = TRUE)
}

jobs <- data.frame(
  script = c(
    "code/Case1/Case1+normal/055.R",
    "code/Case1/Case1+normal/095.R",
    "code/Case1/Case1+t/t055.R",
    "code/Case1/Case1+t/t095.R",
    "code/Case1/Case1+chisq/chisq055.R",
    "code/Case1/Case1+chisq/chisq095.R",
    "code/Case1/Case1+exp/exp055.R",
    "code/Case1/Case1+exp/exp095.R",
    "code/Case2/Case2+normal/normal055.R",
    "code/Case2/Case2+normal/normal095.R",
    "code/Case2/Case2+t/t055.R",
    "code/Case2/Case2+t/t095.R",
    "code/Case2/Case2+chisq/055.R",
    "code/Case2/Case2+chisq/095.R",
    "code/Case2/Case2+exp/exp055.R",
    "code/Case2/Case2+exp/exp095.R"
  ),
  source_output = c(
    "055.RData", "095200.RData", "t055.RData", "t095.RData",
    "chisq055.RData", "chisq095.RData", "exp055.RData", "exp095.RData",
    "normal055.RData", "normal0952.RData", "055.RData", "095.RData",
    "055.RData", "095.RData", "exp055.RData", "exp095.RData"
  ),
  result_output = c(
    "case1_normal_p055.RData", "case1_normal_p095.RData",
    "case1_t3_p055.RData", "case1_t3_p095.RData",
    "case1_chisq6_p055.RData", "case1_chisq6_p095.RData",
    "case1_exponential_p055.RData", "case1_exponential_p095.RData",
    "case2_normal_p055.RData", "case2_normal_p095.RData",
    "case2_t3_p055.RData", "case2_t3_p095.RData",
    "case2_chisq6_p055.RData", "case2_chisq6_p095.RData",
    "case2_exponential_p055.RData", "case2_exponential_p095.RData"
  ),
  stringsAsFactors = FALSE
)

results_dir <- file.path(repo_root, "results")
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)

rscript_bin <- file.path(
  R.home("bin"),
  if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript"
)

for (i in seq_len(nrow(jobs))) {
  script_abs <- file.path(repo_root, jobs$script[[i]])
  scenario_dir <- dirname(script_abs)
  message(sprintf("[%d/%d] Running %s", i, nrow(jobs), jobs$script[[i]]))

  previous_dir <- getwd()
  setwd(scenario_dir)
  status <- system2(rscript_bin, basename(script_abs))
  setwd(previous_dir)

  if (!identical(status, 0L)) {
    stop(sprintf("Scenario failed with status %s: %s", status, jobs$script[[i]]))
  }

  generated_file <- file.path(scenario_dir, jobs$source_output[[i]])
  result_file <- file.path(results_dir, jobs$result_output[[i]])

  if (!file.exists(generated_file)) {
    stop(sprintf("Expected output was not created: %s", generated_file))
  }

  copied <- file.copy(generated_file, result_file, overwrite = TRUE)
  if (!copied) {
    stop(sprintf("Could not copy output to: %s", result_file))
  }
}

capture.output(sessionInfo(), file = file.path(results_dir, "sessionInfo.txt"))
message("All scenarios completed. Consolidated outputs are in: ", results_dir)
