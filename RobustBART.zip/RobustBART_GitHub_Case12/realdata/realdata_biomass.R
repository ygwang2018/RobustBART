rm(list=ls())

source("Func1.R")

library(modeldata)

head(biomass)

dim(biomass)

index <- which(biomass$dataset=="Training")

length(which(biomass$dataset=="Training"))

bio_realdata1 <- bio_realdata <- biomass[index,3:8]

###  p: The proportion of data to be attacked

random_attack1 = function(mu, sigma, yt, p) {
  prop = floor(p*length(yt))
  prop_idx = sample(1:length(yt), size = prop)
  s = rnorm(prop, mu, sigma)
  yt[prop_idx] = (1+s/100)*yt[prop_idx]
  return(yt)
}

#######################
random_attack2 = function(X, p) {
  n = dim(X)[1]
  prop = floor(p*n)
  prop_idx = sample(1:n, size = prop)
  X[prop_idx,1] = rep(100,prop)
  return(X)
}
#######################

###p: The proportion of data to be attacked
#mu = 2*19     #mean(bio_realdata$HHV)=18.98,sd(bio_realdata$HHV)=3.38
#sigma = 20
#yt = bio_realdata$HHV
#p1 = 0.1
#bio_realdata1[,6] <- random_attack(mu, sigma, yt, p1)
#n1 = 80

set.seed(111)

MAPE_1 = MAPE_H = MAPE_b = MAPE = MAPE_RF = MAPE_svm = c(); 

MAE_1 = MAE_H = MAE_b = MAE = MAE_RF = MAE_svm = c();

p_1 = p_H = p_b = c(); 

time_H = time_1 = time_b = time_def = RF_time = svm_time = c();

q = 1.28

maxIters = 20

tol = 1e-4

sigma_p = 0.25

###

X <- bio_realdata1[,1:5]

p = 0.1

mu = 2*19     #mean(bio_realdata$HHV)=18.98,sd(bio_realdata$HHV)=3.38

sigma = 20

yt = bio_realdata$HHV

for (j in 1:200){
  
  y <- random_attack1(mu, sigma, yt, p)
  
  X <- random_attack2(X, p)
    
  y_true <- bio_realdata[,6]

###def

t1<-Sys.time()

model_updated = bartMachine(X, y)

bart11 = bart_predict_for_test_data(model_updated, Xtest=X, ytest=y)

t11<-Sys.time()

time_def<-c(time_def,t11-t1)

MAPE = c(MAPE,MAPE(bart11$y_hat, y_true))

MAE = c(MAE,MAE(bart11$y_hat, y_true))

###01

t2<-Sys.time()

result = ALTS01(X, y, q = 1.28, 
                residual_initial = model_updated$residuals)

bart22 = bart_predict_for_test_data(result$model, Xtest=X, ytest=y)

t22<-Sys.time()

time_1<-c(time_1,t22-t2)

MAPE_1= c(MAPE_1,MAPE(bart22$y_hat,y_true))

MAE_1 = c(MAE_1,MAE(bart22$y_hat,y_true))

p_1 = c(p_1, result$p[length(result$p)])

###Huber

t3<-Sys.time()

result3 = ALTSHuber(X, y, q = 1.28, 
                    residual_initial = model_updated$residuals)

t33<-Sys.time()

time_H<-c(time_H,t33-t3)

MAPE_H= c(MAPE_H,MAPE(result3$mu,y_true))

MAE_H = c(MAE_H,MAE(result3$mu,y_true))

p_H = c(p_H, result3$p[length(result3$p)])

###bisquare

t4<-Sys.time()

result4 = ALTSbisquare(X, y, q = 1.28, 
                       residual_initial = model_updated$residuals)

t44<-Sys.time()

time_b<-c(time_b,t44-t4)

MAPE_b= c(MAPE_b,MAPE(result4$mu,y_true))

MAE_b = c(MAE_b,MAE(result4$mu,y_true))

p_b = c(p_b, result4$p[length(result4$p)])

#Sigma_b = c(Sigma_b, result4$sigma[length(result4$sigma)])

#RF

t5<-Sys.time()

rf<-randomForest(X, y)

aa3<-predict(rf,newdata=data.frame(X, y))

t55<-Sys.time()

RF_time<-t55-t5 

MAPE_RF = c(MAPE_RF,MAPE(aa3, y_true))

MAE_RF = c(MAE_RF,MAE(aa3, y_true))

#svm

t6<-Sys.time()

svm1 <- svm(X, y,type='eps-regression',kernel="radial")

svm1_Pre<-predict(svm1,X)

t66<-Sys.time()

svm_time<-t66-t6

MAPE_svm = c(MAPE_svm,MAPE(svm1_Pre, y_true))

MAE_svm = c(MAE_svm,MAE(svm1_Pre, y_true))

}

save(MAPE_1, MAPE_H, MAPE_b, MAPE, MAPE_RF, MAPE_svm, 
     MAE_1, MAE_H, MAE_b, MAE, MAE_RF, MAE_svm, 
     p_1,p_H,p_b,
     time_H,time_1,time_b,time_def,RF_time,svm_time,
     file = "bio.RData")

