
library(EnvStats)       
library(bartMachine)
library(MLmetrics)      
library(quantreg)       
library(boot)           
library(randomForest)    
library(e1071)           
################################################################################
## functions
################################################################################
## Contents (in order of presentation):
##  1: modified_mad
##          Compute the modified MAD estimator.   sigma
##
##  2. p_estimator(residual, sigma, q)
##          Compute the revised estimate of p = h/N.  
##
##  3. weights_calculation(residual, p)
##          Compute the weights for three: W_0、W_huber and W_bisquare.
##
##  4. ALTS(X,y, q = 1.0, maxIters = 20, tol = 1e-4, sigma_p = 0.25, residual_initial = bartMachine(X, y)$residuals)
##          Fit model using ALTS.
##
################################################################################
## modified_mad(residual, quantile)
##  Compute the modified MAD estimator.
##
## Arguments:
##  residual: Vector of residuals.
##  quantile: Estimate for p, the proportion of clean data.
##
## Outputs:
##  The modified MAD estimator, given as a standard deviation.
################################################################################
modified_mad = function(residual, quantile) {
  # Compute the numerator
  abs_e = abs(residual- median(residual)) 
  sort_e = sort(abs_e)
  h = floor(length(residual) * quantile)
  num_scale = sum(sort_e[1:h]^2)
  # Compute the denominator
  N = length(residual)
  p = (1:h)/(N+1)
  eta = qnormTrunc(p, mean = 0, sd = 1, min = 0, max = Inf)^2 
  mean_eta = sum(eta)
  # Compute sigma 
  sigma = sqrt(num_scale/mean_eta)
  return(sigma)
}

################################################################################
## p_estimator(residual, sigma, q)
##  Compute the revised estimate of p = h/N.
##
## Arguments:
##  residual: Vector of residuals.
##  sigma: Estimate for the standard deviation of the clean data.
##  q: The value of `q` used in the ALTS algorithm.
##
## Outputs:
##  An estimate for ‘p’,= the proportion of clean data.
################################################################################
p_estimator = function(residual, sigma, q) {
  # Compute E[Si^2]
  N = length(residual)
  p = (1:N)/(N+1)
  xi = qnormTrunc(p, mean = 0, sd = sigma, min = 0, max = Inf)  
  Esi2 = cumsum(xi^2) 
  # Compute p 
  abs_e = abs(residual)
  sort_e = sort(abs_e)
  si2 = cumsum(sort_e^2)
  ratio = si2/Esi2 
  inequal = ratio <= q  
  p = sum(inequal)/N
  return(p)
}

################################################################################
## weights_calculation(residual, p)
##  Compute the weights for 01、huber、bisquare.
##
## Arguments:
##  residual: Vector of residuals.
##  p: An estimate for ‘p’, the proportion of clean data.
##
## Outputs:
##  The weights for 01、huber、bisquare.
################################################################################
######01
weights_calculation01 = function(residual, p) {
  N = length(residual)
  h = floor(N*p)
  hc = N - h
  abs_e = abs(residual)
  sort_e_idx = sort(abs_e, index.return = TRUE)$ix  
  weights = array()
  weights[sort_e_idx] = c(array(1, h), array(0, hc))
  return(weights)
}

######huber
weights_calculationHuber = function(residual, p) {
  N = length(residual)
  h = floor(N*p)
  hc = N - h
  abs_e = abs(residual)
  sort_e_idx = sort(abs_e, index.return = TRUE)$ix  
  sort_e_value = sort(abs_e, index.return = TRUE)$x
  kk = sort_e_value[h]
  weights = array()
  weights[sort_e_idx] = c(array(1, h), array(kk/sort_e_value[-(1:h)], hc))
  return(weights)
}

######bisquare
weights_calculationbisquare = function(residual, p) {
  N = length(residual)
  h = floor(N*p)
  hc = N - h
  abs_e = abs(residual)
  sort_e_idx = sort(abs_e, index.return = TRUE)$ix  
  sort_e_value = sort(abs_e, index.return = TRUE)$x
  kk<-sort_e_value[h]
  weights = array()
  weights[sort_e_idx] = c(array((1-(sort_e_value[1:h]^2/kk^2))^2, h), array(0, hc))
  return(weights)
}

################################################################################
## ALTS(X,y, q = 1.0, maxIters = 20, tol = 1e-4, sigma_p = 0.25, 
##      residual_initial = bartMachine(X, y)$residuals)
##  Fit model using ALTS.
##
## Arguments:
##  X,y
##  q = 1.0: Value for the hyperparameter 'q'.
##  maxIters = 20: The maximum allowable number of iterations.
##  tol = 1e-4: Threshold for the convergence, based on 'abs(p[i] - p[i-1])/p[i] < tol'.
##  sigma_p = 0.25: Upper index to use in the modified MAD estimator.
##  residual_initial = bartMachine(X, y)$residuals: Initial vector of residuals.
##
## Outputs:
##  The output is a list containing the following:
##    $p: The vector of p iterates.
##    $model: The final model.
##    $mu: The vector of y for estimator
##    $e: The vector of residual 
################################################################################
######
ALTSbisquare = function(X, y, q = 1.2, maxIters = 20, tol = 1e-4, sigma_p = 0.25, 
                        residual_initial = bartMachine(X, y)$residuals) {
  sigma_initial = modified_mad(residual_initial, sigma_p)
  p_initial = 0.5
  weight = weights_calculationbisquare(residual_initial, p_initial)
  weight = weight/sum(weight)   
  n_bootstrap <- 1000
  e_hat <- matrix(NA, nrow = n_bootstrap, ncol = length(y))
  y_hat <- matrix(NA, nrow = n_bootstrap, ncol = length(y))
  for (ii in 1:n_bootstrap) {
    sample_indices <- sample(1:length(y), size = length(y), replace = TRUE, prob = weight)
    model_updated <- bartMachine(X[sample_indices,], y[sample_indices])
    bart1 = bart_predict_for_test_data(model_updated, Xtest=X, ytest=y)
    e_hat[ii, ] <- bart1$e
    y_hat[ii, ] <- bart1$y_hat
  }
  e_mean <- colMeans(e_hat)
  y_hat_mean <- colMeans(y_hat)
  for (i in 2:maxIters) {
    updated_residuals = e_mean
    sigma_initial[i] = modified_mad(updated_residuals, sigma_p)
    p_initial[i] = p_estimator(updated_residuals, sigma_initial[i], q)
    if (p_initial[i] < 0.5) {
      p_initial[i] = 0.5
      break
    }
    weight = weights_calculationbisquare(updated_residuals, p_initial[i])
    weight = weight/sum(weight)
    n_bootstrap <- 1000
    e_hat <- matrix(NA, nrow = n_bootstrap, ncol = length(y))
    y_hat <- matrix(NA, nrow = n_bootstrap, ncol = length(y))
    for (ii in 1:n_bootstrap) {
      sample_indices <- sample(1:length(y), size = length(y), replace = TRUE, prob = weight)
      model_updated <- bartMachine(X[sample_indices,], y[sample_indices])
      bart1 = bart_predict_for_test_data(model_updated, Xtest=X, ytest=y)
      e_hat[ii, ] <- bart1$e
      y_hat[ii, ] <- bart1$y_hat
    }
    e_mean <- colMeans(e_hat)
    y_hat_mean <- colMeans(y_hat)
  
    if (abs(p_initial[i] - p_initial[i-1])/p_initial[i] < tol) {
      break
    }
  }
  return(list(p = p_initial, e = e_mean, mu = y_hat_mean))
}

######
ALTS01 = function(X, y, q = 1.28, maxIters = 20, tol = 1e-4, sigma_p = 0.25, 
                  residual_initial = bartMachine(X, y)$residuals) {
  sigma_initial = modified_mad(residual_initial, sigma_p)
  p_initial = 0.5
  weight = weights_calculation01(residual_initial, p_initial)
  index1 = which(weight==1)
  model_updated = bartMachine(X[index1,], y[index1])
  bart1 = bart_predict_for_test_data(model_updated, Xtest=X, ytest=y)
  for (i in 2:maxIters) {
    updated_residuals = bart1$e
    sigma_initial[i] = modified_mad(updated_residuals, sigma_p)
    p_initial[i] = p_estimator(updated_residuals, sigma_initial[i], q)
    if (p_initial[i] < 0.5) {
      p_initial[i] = 0.5
      break
    }
    weight = weights_calculation01(updated_residuals, p_initial[i])
    index1 = which(weight==1)
    model_updated = bartMachine(X[index1,], y[index1])
    bart1 = bart_predict_for_test_data(model_updated, Xtest=X, ytest=y)
    if (abs(p_initial[i] - p_initial[i-1])/p_initial[i] < tol) {
      break
    }
  }
  return(list(p = p_initial, model = model_updated,
              mu = bart1$y_hat))
}

######
ALTSHuber = function(X, y, q = 1.28, maxIters = 20, tol = 1e-4, sigma_p = 0.25, 
                     residual_initial = bartMachine(X, y)$residuals) {
  sigma_initial = modified_mad(residual_initial, sigma_p)
  p_initial = 0.5
  weight = weights_calculationHuber(residual_initial, p_initial)
  weight = weight/sum(weight)   
  n_bootstrap <- 1000
  e_hat <- matrix(NA, nrow = n_bootstrap, ncol = length(y))
  y_hat <- matrix(NA, nrow = n_bootstrap, ncol = length(y))
  for (ii in 1:n_bootstrap) {
    sample_indices <- sample(1:length(y), size = length(y), replace = TRUE, prob = weight)
    model_updated <- bartMachine(X[sample_indices,], y[sample_indices])
    bart1 = bart_predict_for_test_data(model_updated, Xtest=X, ytest=y)
    e_hat[ii, ] <- bart1$e
    y_hat[ii, ] <- bart1$y_hat
  }
   e_mean <- colMeans(e_hat)
   y_hat_mean <- colMeans(y_hat)
  for (i in 2:maxIters) {
    updated_residuals = e_mean
    sigma_initial[i] = modified_mad(updated_residuals, sigma_p)
    p_initial[i] = p_estimator(updated_residuals, sigma_initial[i], q)
    if (p_initial[i] < 0.5) {
      p_initial[i] = 0.5
      break
    }
    weight = weights_calculationHuber(updated_residuals, p_initial[i])
    weight = weight/sum(weight)
    ###
    n_bootstrap <- 1000
    e_hat <- matrix(NA, nrow = n_bootstrap, ncol = length(y))
    y_hat <- matrix(NA, nrow = n_bootstrap, ncol = length(y))
    for (ii in 1:n_bootstrap) {
      sample_indices <- sample(1:length(y), size = length(y), replace = TRUE, prob = weight)
      model_updated <- bartMachine(X[sample_indices,], y[sample_indices])
      bart1 = bart_predict_for_test_data(model_updated, Xtest=X, ytest=y)
      e_hat[ii, ] <- bart1$e
      y_hat[ii, ] <- bart1$y_hat
    }
    e_mean <- colMeans(e_hat)
    y_hat_mean <- colMeans(y_hat)
    if (abs(p_initial[i] - p_initial[i-1])/p_initial[i] < tol) {
      break
    }
  }
  return(list(p = p_initial, e = e_mean, mu = y_hat_mean))
}
