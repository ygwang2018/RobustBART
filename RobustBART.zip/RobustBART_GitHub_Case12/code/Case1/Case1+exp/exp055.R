source("Func1.R")

set.seed(111)

MAPE_1 = MAPE_H = MAPE_b = MAPE = MAPE_RF = MAPE_svm = c(); 

MAE_1 = MAE_H = MAE_b = MAE = MAE_RF = MAE_svm = c();

p_1 = p_H = p_b = c(); 

time_H = time_1 = time_b = time_def = RF_time = svm_time = c();

Sigma_1 = Sigma_H = Sigma_b = c();

nobs = 100

dim = 5

X = data.frame(matrix(runif(nobs*dim),ncol = dim))

## Parameters 
sigma_1 = 1

#sigma_2 = 5

mu_0 = 10 * sin(pi* X[ ,1] * X[,2]) +20 * (X[,3] -.5)^2 + 10 * X[ ,4] + 5 * X[,5]

p = 0.55

q = 1.28

maxIters = 20

tol = 1e-4

sigma_p = 0.25

###

for (j in 1:200){
  
  h = floor(p * nobs)
  
  noise_good = rnorm(h, 0, sigma_1)
  
  noise_outlier = rexp(nobs - h, rate=0.5)-2
  
  noise = c(noise_good, noise_outlier)
  
  y = mu_0 + noise
  
  idex <- sample(1:nobs,nobs-h)
  
  X[idex,1] <- rep(5,nobs - h)
  
  ###def
  
  t1<-Sys.time()
  
  model_updated = bartMachine(X, y)
  
  bart11 = bart_predict_for_test_data(model_updated, Xtest=X, ytest=y)
  
  t11<-Sys.time()
  
  time_def<-c(time_def,t11-t1)
  
  MAPE = c(MAPE,MAPE(bart11$y_hat, mu_0))
  
  MAE = c(MAE,MAE(bart11$y_hat, mu_0))
  
  ###01
  
  t2<-Sys.time()
  
  result = ALTS01(X, y, q = 1.28, 
                  residual_initial = model_updated$residuals)
  
  bart22 = bart_predict_for_test_data(result$model, Xtest=X, ytest=y)
  
  t22<-Sys.time()
  
  time_1<-c(time_1,t22-t2)
  
  MAPE_1= c(MAPE_1,MAPE(bart22$y_hat,mu_0))
  
  MAE_1 = c(MAE_1,MAE(bart22$y_hat,mu_0))
  
  p_1 = c(p_1, result$p[length(result$p)])
  
  Sigma_1 = c(Sigma_1, result$sigma[length(result$sigma)])
                
  ###Huber
  
  t3<-Sys.time()
  
  result3 = ALTSHuber(X, y, q = 1.28, 
                      residual_initial = model_updated$residuals)
  
  t33<-Sys.time()
  
  time_H<-c(time_H,t33-t3)
  
  MAPE_H= c(MAPE_H,MAPE(result3$mu,mu_0))
  
  MAE_H = c(MAE_H,MAE(result3$mu,mu_0))
  
  p_H = c(p_H, result3$p[length(result3$p)])
  
  Sigma_H = c(Sigma_H, result3$sigma[length(result3$sigma)])
                                     
  ###bisquare
  
  t4<-Sys.time()
  
  result4 = ALTSbisquare(X, y, q = 1.28, 
                         residual_initial = model_updated$residuals)
  
  t44<-Sys.time()
  
  time_b<-c(time_b,t44-t4)
  
  MAPE_b= c(MAPE_b,MAPE(result4$mu,mu_0))
  
  MAE_b = c(MAE_b,MAE(result4$mu,mu_0))
  
  p_b = c(p_b, result4$p[length(result4$p)])
  
  Sigma_b = c(Sigma_b, result4$sigma[length(result4$sigma)])
  
  
  #RF
  
  t5<-Sys.time()
  
  rf<-randomForest(X, y)
  
  aa3<-predict(rf,newdata=data.frame(X, y))
  
  t55<-Sys.time()
  
  RF_time<-t55-t5 
  
  MAPE_RF = c(MAPE_RF,MAPE(aa3, mu_0))
  
  MAE_RF = c(MAE_RF,MAE(aa3, mu_0))
  
  #svm
  
  t6<-Sys.time()
  
  svm1 <- svm(X, y,type='eps-regression',kernel="radial")
  
  svm1_Pre<-predict(svm1,X)
  
  t66<-Sys.time()
  
  svm_time<-t66-t6
  
  MAPE_svm = c(MAPE_svm,MAPE(svm1_Pre, mu_0))
  
  MAE_svm = c(MAE_svm,MAE(svm1_Pre, mu_0))
  
}

save(MAPE_1, MAPE_H, MAPE_b, MAPE, MAPE_RF, MAPE_svm, 
     MAE_1, MAE_H, MAE_b, MAE, MAE_RF, MAE_svm, 
     p_1,p_H,p_b,Sigma_1,Sigma_H,Sigma_b,
     time_H,time_1,time_b,time_def,RF_time,svm_time,
     file = "exp055.RData")


